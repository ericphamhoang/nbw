<?php
/**
 * This class is mainly for Page Template management as well as appending custom assets into the site
 * User: nkahoang
 * Date: 8/07/2014
 * Time: 8:38 PM
 */

class NBWHooksAndFilters {
    public static function register_hooks_and_filters() {

    }
}