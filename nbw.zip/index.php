<?php
// Silence is golden
// This file is created so that if anyone navigate to wp-content/plugins/nbw, directory listing will not be displayed