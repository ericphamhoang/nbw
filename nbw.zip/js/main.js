(function() {
  window.NBW = {
    init: function() {
      return console.log("NBW Site Initialised!");
    }
  };

}).call(this);
